package com.trafficlight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartTrafficLightBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
