package com.trafficlight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartTrafficLightBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartTrafficLightBackendApplication.class, args);
    }
}